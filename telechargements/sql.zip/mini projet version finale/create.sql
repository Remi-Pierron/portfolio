BEGIN
    FOR rec IN (SELECT table_name FROM user_tables) LOOP
        EXECUTE IMMEDIATE 'DROP TABLE ' || rec.table_name || ' CASCADE CONSTRAINTS';
    END LOOP;
END;
/


CREATE TABLE patient(
   id_patient VARCHAR(50),
   nom VARCHAR(50),
   prenom VARCHAR(50),
   dateNaissance DATE,
   adresse VARCHAR(50),
   telephone VARCHAR(50),
   PRIMARY KEY(id_patient)
);

CREATE TABLE dossierPatient(
   id_dossier VARCHAR(50),
   id_patient VARCHAR(50),
   dateOuverture DATE,
   dateFermeture DATE,
   motifConsultation VARCHAR(50),
   notesGenerales VARCHAR(500),
   id_patient_1 VARCHAR(50) NOT NULL,
   PRIMARY KEY(id_dossier),
   FOREIGN KEY(id_patient_1) REFERENCES patient(id_patient)
);

CREATE TABLE traitement(
   id_traitement VARCHAR(50),
   id_dossier VARCHAR(50),
   dateTraitement DATE,
   cout DECIMAL(15,2),
   details VARCHAR(50),
   id_dossier_1 VARCHAR(50) NOT NULL,
   PRIMARY KEY(id_traitement),
   FOREIGN KEY(id_dossier_1) REFERENCES dossierPatient(id_dossier)
);

CREATE TABLE personnel(
   id_personnel VARCHAR(50),
   nom VARCHAR(50),
   prenom VARCHAR(50),
   specialite VARCHAR(50),
   role VARCHAR(50),
   PRIMARY KEY(id_personnel)
);

CREATE TABLE franchise(
   id_franchise VARCHAR(50),
   nom VARCHAR(50),
   adresse VARCHAR(50),
   telephone VARCHAR(50),
   PRIMARY KEY(id_franchise)
);

CREATE TABLE produitDentaire(
   id_produit VARCHAR(50),
   nom VARCHAR(50),
   description VARCHAR(500),
   quantite VARCHAR(50),
   PRIMARY KEY(id_produit)
);

CREATE TABLE fournisseur(
   id_fournisseur VARCHAR(50),
   nom VARCHAR(50),
   adresse VARCHAR(50),
   telephone VARCHAR(50),
   PRIMARY KEY(id_fournisseur)
);

CREATE TABLE commande(
   id_commande VARCHAR(50),
   id_fournisseur VARCHAR(50),
   dateCommande DATE,
   details VARCHAR(500),
   PRIMARY KEY(id_commande)
);

CREATE TABLE equipement(
   id_equipement VARCHAR(50),
   nom VARCHAR(50),
   description VARCHAR(500),
   quantite VARCHAR(50),
   coutUtilisation DECIMAL(15,2),
   PRIMARY KEY(id_equipement)
);

CREATE TABLE dent(
   id_dent VARCHAR(50),
   id_patient VARCHAR(50),
   codeFDI VARCHAR(50),
   id_patient_1 VARCHAR(50) NOT NULL,
   PRIMARY KEY(id_dent),
   FOREIGN KEY(id_patient_1) REFERENCES patient(id_patient)
);

CREATE TABLE etatDent(
   id_etatDent VARCHAR(50),
   id_dent VARCHAR(50),
   dateObservation DATE,
   anomalies VARCHAR(50),
   restaurations VARCHAR(50),
   id_dent_1 VARCHAR(50) NOT NULL,
   PRIMARY KEY(id_etatDent),
   FOREIGN KEY(id_dent_1) REFERENCES dent(id_dent)
);

CREATE TABLE anomalie(
   id_anomalie VARCHAR(50),
   type VARCHAR(50),
   description VARCHAR(50),
   gravite VARCHAR(50),
   id_etatDent VARCHAR(50) NOT NULL,
   PRIMARY KEY(id_anomalie),
   FOREIGN KEY(id_etatDent) REFERENCES etatDent(id_etatDent)
);

CREATE TABLE restauration(
   id_restauration VARCHAR(50),
   type VARCHAR(50),
   matériau VARCHAR(50),
   dureeDeVieEstimee VARCHAR(50),
   id_etatDent VARCHAR(50) NOT NULL,
   PRIMARY KEY(id_restauration),
   FOREIGN KEY(id_etatDent) REFERENCES etatDent(id_etatDent)
);

CREATE TABLE acteMedical(
   id_acte VARCHAR(50),
   id_traitement VARCHAR(50),
   description VARCHAR(500),
   practicienResponsable VARCHAR(50),
   typeActe VARCHAR(50),
   montant DECIMAL(15,2),
   radiographie VARCHAR(50),
   prescriptions VARCHAR(500),
   id_personnel VARCHAR(50) NOT NULL,
   id_traitement_1 VARCHAR(50) NOT NULL,
   PRIMARY KEY(id_acte),
   FOREIGN KEY(id_personnel) REFERENCES personnel(id_personnel),
   FOREIGN KEY(id_traitement_1) REFERENCES traitement(id_traitement)
);

CREATE TABLE paiement(
   id_paiement VARCHAR(50),
   id_acte VARCHAR(50),
   datePaiement DATE,
   montant VARCHAR(50),
   id_acte_1 VARCHAR(50) NOT NULL,
   PRIMARY KEY(id_paiement),
   FOREIGN KEY(id_acte_1) REFERENCES acteMedical(id_acte)
);

CREATE TABLE comporte(
   id_traitement VARCHAR(50),
   id_produit VARCHAR(50),
   PRIMARY KEY(id_traitement, id_produit),
   FOREIGN KEY(id_traitement) REFERENCES traitement(id_traitement),
   FOREIGN KEY(id_produit) REFERENCES produitDentaire(id_produit)
);

CREATE TABLE est_fourni_par(
   id_produit VARCHAR(50),
   id_fournisseur VARCHAR(50),
   PRIMARY KEY(id_produit, id_fournisseur),
   FOREIGN KEY(id_produit) REFERENCES produitDentaire(id_produit),
   FOREIGN KEY(id_fournisseur) REFERENCES fournisseur(id_fournisseur)
);

CREATE TABLE est_adressee_a(
   id_fournisseur VARCHAR(50),
   id_commande VARCHAR(50),
   PRIMARY KEY(id_fournisseur, id_commande),
   FOREIGN KEY(id_fournisseur) REFERENCES fournisseur(id_fournisseur),
   FOREIGN KEY(id_commande) REFERENCES commande(id_commande)
);

CREATE TABLE appartient_a(
   id_personnel VARCHAR(50),
   id_franchise VARCHAR(50),
   PRIMARY KEY(id_personnel, id_franchise),
   FOREIGN KEY(id_personnel) REFERENCES personnel(id_personnel),
   FOREIGN KEY(id_franchise) REFERENCES franchise(id_franchise)
);

CREATE TABLE est_possede_par(
   id_franchise VARCHAR(50),
   id_equipement VARCHAR(50),
   PRIMARY KEY(id_franchise, id_equipement),
   FOREIGN KEY(id_franchise) REFERENCES franchise(id_franchise),
   FOREIGN KEY(id_equipement) REFERENCES equipement(id_equipement)
);
