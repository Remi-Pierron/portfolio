/*table patient*/

INSERT INTO patient (id_patient, nom, prenom, dateNaissance, adresse, telephone) 
VALUES ('PAT001', 'Dupont', 'Jean', TO_DATE('1985-06-15', 'YYYY-MM-DD'), '123 Rue des Lilas, Paris', '0601234567');

INSERT INTO patient (id_patient, nom, prenom, dateNaissance, adresse, telephone) 
VALUES ('PAT002', 'Martin', 'Sophie', TO_DATE('1990-09-23', 'YYYY-MM-DD'), '45 Avenue de la République, Lyon', '0612345678');

INSERT INTO patient (id_patient, nom, prenom, dateNaissance, adresse, telephone) 
VALUES ('PAT003', 'Durand', 'Paul', TO_DATE('1978-12-02', 'YYYY-MM-DD'), '78 Boulevard Haussmann, Marseille', '0623456789');

INSERT INTO patient (id_patient, nom, prenom, dateNaissance, adresse, telephone) 
VALUES ('PAT004', 'Morel', 'Claire', TO_DATE('2000-03-10', 'YYYY-MM-DD'), '12 Impasse des Érables, Toulouse', '0634567890');

INSERT INTO patient (id_patient, nom, prenom, dateNaissance, adresse, telephone) 
VALUES ('PAT005', 'Rousseau', 'Luc', TO_DATE('1995-07-19', 'YYYY-MM-DD'), '34 Allée des Cerisiers, Nice', '0645678901');

INSERT INTO patient (id_patient, nom, prenom, dateNaissance, adresse, telephone) 
VALUES ('PAT006', 'Lemoine', 'Isabelle', TO_DATE('1987-02-03', 'YYYY-MM-DD'), '56 Rue du Parc, Bordeaux', '0609876543');

INSERT INTO patient (id_patient, nom, prenom, dateNaissance, adresse, telephone) 
VALUES ('PAT007', 'Leclerc', 'Pierre', TO_DATE('1975-11-25', 'YYYY-MM-DD'), '89 Rue des Champs, Lille', '0612345679');

INSERT INTO patient (id_patient, nom, prenom, dateNaissance, adresse, telephone) 
VALUES ('PAT008', 'Garnier', 'Élise', TO_DATE('1992-07-11', 'YYYY-MM-DD'), '102 Boulevard des Fleurs, Nantes', '0623456781');

INSERT INTO patient (id_patient, nom, prenom, dateNaissance, adresse, telephone) 
VALUES ('PAT009', 'Benoit', 'Marc', TO_DATE('1983-01-18', 'YYYY-MM-DD'), '23 Rue de la Liberté, Strasbourg', '0634567892');

INSERT INTO patient (id_patient, nom, prenom, dateNaissance, adresse, telephone) 
VALUES ('PAT010', 'Charpentier', 'Julie', TO_DATE('1997-04-30', 'YYYY-MM-DD'), '15 Quai de la Seine, Paris', '0645678903');

INSERT INTO patient (id_patient, nom, prenom, dateNaissance, adresse, telephone) 
VALUES ('PAT011', 'Pires', 'Antoine', TO_DATE('1990-02-20', 'YYYY-MM-DD'), '123 Rue de la Gare, Paris', '0601234568');

/*table dossierPatient*/

INSERT INTO dossierPatient (id_dossier, id_patient, dateOuverture, dateFermeture, motifConsultation, notesGenerales, id_patient_1)
VALUES ('DOS001', 'PAT001', TO_DATE('2023-01-10', 'YYYY-MM-DD'), NULL, 'Douleur dentaire', 'Patient stressé, prévoir consultation de suivi', 'PAT001');

INSERT INTO dossierPatient (id_dossier, id_patient, dateOuverture, dateFermeture, motifConsultation, notesGenerales, id_patient_1)
VALUES ('DOS002', 'PAT002', TO_DATE('2022-11-05', 'YYYY-MM-DD'), TO_DATE('2023-02-15', 'YYYY-MM-DD'), 'Caries multiples', 'Traitement terminé, prévoir contrôle dans 6 mois', 'PAT002');

INSERT INTO dossierPatient (id_dossier, id_patient, dateOuverture, dateFermeture, motifConsultation, notesGenerales, id_patient_1)
VALUES ('DOS003', 'PAT003', TO_DATE('2023-07-20', 'YYYY-MM-DD'), NULL, 'Blanchiment des dents', 'Traitement esthétique en cours', 'PAT003');

INSERT INTO dossierPatient (id_dossier, id_patient, dateOuverture, dateFermeture, motifConsultation, notesGenerales, id_patient_1)
VALUES ('DOS004', 'PAT004', TO_DATE('2023-03-25', 'YYYY-MM-DD'), NULL, 'Extraction de dent', 'Prévoir contrôle postopératoire', 'PAT004');

INSERT INTO dossierPatient (id_dossier, id_patient, dateOuverture, dateFermeture, motifConsultation, notesGenerales, id_patient_1)
VALUES ('DOS005', 'PAT005', TO_DATE('2022-09-15', 'YYYY-MM-DD'), TO_DATE('2023-01-10', 'YYYY-MM-DD'), 'Implant dentaire', 'Traitement finalisé avec succès', 'PAT005');

INSERT INTO dossierPatient (id_dossier, id_patient, dateOuverture, dateFermeture, motifConsultation, notesGenerales, id_patient_1)
VALUES ('DOS006', 'PAT006', TO_DATE('2023-08-12', 'YYYY-MM-DD'), NULL, 'Douleur aux gencives', 'Prévoir un suivi pour traitement des gencives', 'PAT006');

INSERT INTO dossierPatient (id_dossier, id_patient, dateOuverture, dateFermeture, motifConsultation, notesGenerales, id_patient_1)
VALUES ('DOS007', 'PAT007', TO_DATE('2023-04-05', 'YYYY-MM-DD'), TO_DATE('2023-07-10', 'YYYY-MM-DD'), 'Caries dentaires', 'Traitement terminé, contrôle dans 3 mois', 'PAT007');

INSERT INTO dossierPatient (id_dossier, id_patient, dateOuverture, dateFermeture, motifConsultation, notesGenerales, id_patient_1)
VALUES ('DOS008', 'PAT008', TO_DATE('2023-09-15', 'YYYY-MM-DD'), NULL, 'Révision de couronne', 'Consultation de suivi prévue', 'PAT008');

INSERT INTO dossierPatient (id_dossier, id_patient, dateOuverture, dateFermeture, motifConsultation, notesGenerales, id_patient_1)
VALUES ('DOS009', 'PAT009', TO_DATE('2022-12-01', 'YYYY-MM-DD'), TO_DATE('2023-05-10', 'YYYY-MM-DD'), 'Extraction dentaire', 'Suivi postopératoire prévu', 'PAT009');

INSERT INTO dossierPatient (id_dossier, id_patient, dateOuverture, dateFermeture, motifConsultation, notesGenerales, id_patient_1)
VALUES ('DOS010', 'PAT010', TO_DATE('2023-06-20', 'YYYY-MM-DD'), NULL, 'Contrôle de routine', 'Aucun problème détecté, suivi dans un an', 'PAT010');

INSERT INTO dossierPatient (id_dossier, id_patient, dateOuverture, dateFermeture, motifConsultation, notesGenerales, id_patient_1)
VALUES ('DOS011', 'PAT011', TO_DATE('2023-01-10', 'YYYY-MM-DD'), NULL, 'Douleur dentaire', 'Patient stressé, prévoir consultation de suivi', 'PAT011');

INSERT INTO dossierPatient (id_dossier, id_patient, dateOuverture, dateFermeture, motifConsultation, notesGenerales, id_patient_1)
VALUES ('DOS012', 'PAT011', TO_DATE('2023-02-15', 'YYYY-MM-DD'), TO_DATE('2023-05-01', 'YYYY-MM-DD'), 'Carie', 'Traitement des caries en cours', 'PAT011');

INSERT INTO dossierPatient (id_dossier, id_patient, dateOuverture, dateFermeture, motifConsultation, notesGenerales, id_patient_1)
VALUES ('DOS013', 'PAT011', TO_DATE('2023-06-05', 'YYYY-MM-DD'), NULL, 'Consultation préventive', 'Aucun problème majeur, à revoir dans un an', 'PAT011');

INSERT INTO dossierPatient (id_dossier, id_patient, dateOuverture, dateFermeture, motifConsultation, notesGenerales, id_patient_1)
VALUES ('DOS014', 'PAT011', TO_DATE('2023-09-01', 'YYYY-MM-DD'), NULL, 'Extraction de dent', 'Extraction planifiée pour le mois prochain', 'PAT011');

INSERT INTO dossierPatient (id_dossier, id_patient, dateOuverture, dateFermeture, motifConsultation, notesGenerales, id_patient_1)
VALUES ('DOS018', 'PAT003', TO_DATE('2023-02-05', 'YYYY-MM-DD'), NULL, 'Révision de couronne', 'Suivi après couronne posée, prévoir contrôle', 'PAT003');

INSERT INTO dossierPatient (id_dossier, id_patient, dateOuverture, dateFermeture, motifConsultation, notesGenerales, id_patient_1)
VALUES ('DOS019', 'PAT003', TO_DATE('2023-05-30', 'YYYY-MM-DD'), NULL, 'Consultation esthétique', 'Demande de conseils pour sourire', 'PAT003');

INSERT INTO dossierPatient (id_dossier, id_patient, dateOuverture, dateFermeture, motifConsultation, notesGenerales, id_patient_1)
VALUES ('DOS020', 'PAT003', TO_DATE('2023-08-15', 'YYYY-MM-DD'), NULL, 'Douleur aux gencives', 'Inflammation légère des gencives, prescription de traitement', 'PAT003');

/*table traitement*/

INSERT INTO traitement (id_traitement, id_dossier, dateTraitement, cout, details, id_dossier_1)
VALUES ('TRA001', 'DOS001', TO_DATE('2023-01-12', 'YYYY-MM-DD'), 120.50, 'Consultation initiale et radiographie', 'DOS001');

INSERT INTO traitement (id_traitement, id_dossier, dateTraitement, cout, details, id_dossier_1)
VALUES ('TRA002', 'DOS002', TO_DATE('2022-11-07', 'YYYY-MM-DD'), 250.00, 'Traitement des caries multiples', 'DOS002');

INSERT INTO traitement (id_traitement, id_dossier, dateTraitement, cout, details, id_dossier_1)
VALUES ('TRA003', 'DOS003', TO_DATE('2023-07-25', 'YYYY-MM-DD'), 300.00, 'Première séance de blanchiment', 'DOS003');

INSERT INTO traitement (id_traitement, id_dossier, dateTraitement, cout, details, id_dossier_1)
VALUES ('TRA004', 'DOS004', TO_DATE('2023-03-27', 'YYYY-MM-DD'), 180.00, 'Extraction de dent de sagesse', 'DOS004');

INSERT INTO traitement (id_traitement, id_dossier, dateTraitement, cout, details, id_dossier_1)
VALUES ('TRA005', 'DOS005', TO_DATE('2022-09-20', 'YYYY-MM-DD'), 1500.00, 'Pose d implant dentaire', 'DOS005');


/*table produitDentaire*/

INSERT INTO produitDentaire (id_produit, nom, description, quantite)
VALUES ('PROD001', 'Brosse à dents électrique', 'Brosse à dents électrique avec 3 modes de nettoyage et une tête rotative.', '150');

INSERT INTO produitDentaire (id_produit, nom, description, quantite)
VALUES ('PROD002', 'Fil dentaire', 'Fil dentaire fin pour un nettoyage en profondeur entre les dents.', '500');

INSERT INTO produitDentaire (id_produit, nom, description, quantite)
VALUES ('PROD003', 'Dentifrice blanchissant', 'Dentifrice à base de peroxyde pour un effet blanchissant sur les dents.', '300');

INSERT INTO produitDentaire (id_produit, nom, description, quantite)
VALUES ('PROD004', 'Gel de désinfection', 'Gel antiseptique pour le traitement des gencives sensibles et des infections buccales.', '100');

INSERT INTO produitDentaire (id_produit, nom, description, quantite)
VALUES ('PROD005', 'Kit de blanchiment', 'Kit complet de blanchiment dentaire incluant une gouttière et un gel de blanchiment.', '75');


-- Insertion des fournisseurs

INSERT INTO fournisseur (id_fournisseur, nom, adresse, telephone)
VALUES ('FOUR001', 'Fournisseur Médical A', '10 Rue des Supplies, 75000 Paris', '01 40 25 30 40');

INSERT INTO fournisseur (id_fournisseur, nom, adresse, telephone)
VALUES ('FOUR002', 'Fournisseur Médical B', '22 Boulevard de la Santé, 69000 Lyon', '04 72 33 77 88');

INSERT INTO fournisseur (id_fournisseur, nom, adresse, telephone)
VALUES ('FOUR003', 'Fournisseur Médical C', '45 Avenue des Médicaux, 13000 Marseille', '04 91 25 59 60');

INSERT INTO fournisseur (id_fournisseur, nom, adresse, telephone)
VALUES ('FOUR004', 'Fournisseur Médical D', '5 Rue des Equipements, 59000 Lille', '03 20 54 12 89');

INSERT INTO fournisseur (id_fournisseur, nom, adresse, telephone)
VALUES ('FOUR005', 'Fournisseur Médical E', '78 Place du Commerce, 31000 Toulouse', '05 61 23 45 22');



/*table commande*/

INSERT INTO commande (id_commande, id_fournisseur, dateCommande, details)
VALUES ('COM001', 'FOURN001', TO_DATE('2023-01-10', 'YYYY-MM-DD'), 'Commande de brosses à dents électriques et dentifrice blanchissant.');

INSERT INTO commande (id_commande, id_fournisseur, dateCommande, details)
VALUES ('COM002', 'FOURN002', TO_DATE('2023-03-15', 'YYYY-MM-DD'), 'Commande de fil dentaire et gel de désinfection pour stock.');

INSERT INTO commande (id_commande, id_fournisseur, dateCommande, details)
VALUES ('COM003', 'FOURN003', TO_DATE('2023-06-01', 'YYYY-MM-DD'), 'Commande de kits de blanchiment dentaire et de brosses à dents.');

INSERT INTO commande (id_commande, id_fournisseur, dateCommande, details)
VALUES ('COM004', 'FOURN004', TO_DATE('2023-08-20', 'YYYY-MM-DD'), 'Commande de matériel d extraction dentaire et de dispositifs de radiographie.');

INSERT INTO commande (id_commande, id_fournisseur, dateCommande, details)
VALUES ('COM005', 'FOURN005', TO_DATE('2023-10-05', 'YYYY-MM-DD'), 'Commande de produits pour soins des gencives et de nettoyants pour équipements.');


/*personnel*/

INSERT INTO personnel (id_personnel, nom, prenom, specialite, role)
VALUES ('PERS001', 'Dupuis', 'Michel', 'Dentiste', 'Praticien');

INSERT INTO personnel (id_personnel, nom, prenom, specialite, role)
VALUES ('PERS002', 'Lefevre', 'Sophie', 'Dentiste', 'Praticien');

INSERT INTO personnel (id_personnel, nom, prenom, specialite, role)
VALUES ('PERS003', 'Bernard', 'Julien', 'Chirurgien-dentiste', 'Praticien');

INSERT INTO personnel (id_personnel, nom, prenom, specialite, role)
VALUES ('PERS004', 'Marais', 'Claire', 'Chirurgien-dentiste', 'Praticien');

INSERT INTO personnel (id_personnel, nom, prenom, specialite, role)
VALUES ('PERS005', 'Chevalier', 'Thierry', 'Chirurgien-dentiste', 'Praticien');




/*table acteMedical*/

INSERT INTO acteMedical (id_acte, id_traitement, description, practicienResponsable, typeActe, montant, radiographie, prescriptions, id_personnel, id_traitement_1)
VALUES ('ACT001', 'TRA001', 'Consultation initiale et radiographie dentaire', 'Dr. Dupuis', 'Consultation', 120.50, 'Radiographie panoramique', 'Antibiotiques prescrits', 'PERS001', 'TRA001');

INSERT INTO acteMedical (id_acte, id_traitement, description, practicienResponsable, typeActe, montant, radiographie, prescriptions, id_personnel, id_traitement_1)
VALUES ('ACT002', 'TRA002', 'Traitement des caries et plombages', 'Dr. Lefevre', 'Traitement', 250.00, NULL, 'Aucun médicament nécessaire', 'PERS002', 'TRA002');

INSERT INTO acteMedical (id_acte, id_traitement, description, practicienResponsable, typeActe, montant, radiographie, prescriptions, id_personnel, id_traitement_1)
VALUES ('ACT003', 'TRA003', 'Blanchiment des dents avec gel professionnel', 'Dr. Bernard', 'Esthétique', 300.00, NULL, 'Crème de protection des gencives', 'PERS003', 'TRA003');

INSERT INTO acteMedical (id_acte, id_traitement, description, practicienResponsable, typeActe, montant, radiographie, prescriptions, id_personnel, id_traitement_1)
VALUES ('ACT004', 'TRA004', 'Extraction dune dent de sagesse', 'Dr. Marais', 'Chirurgie', 180.00, 'Radiographie pré-opératoire', 'Aucun médicament nécessaire', 'PERS004', 'TRA004');

INSERT INTO acteMedical (id_acte, id_traitement, description, practicienResponsable, typeActe, montant, radiographie, prescriptions, id_personnel, id_traitement_1)
VALUES ('ACT005', 'TRA005', 'Pose d implant dentaire avec suivi post-opératoire', 'Dr. Chevalier', 'Chirurgie', 1500.00, 'Radiographie post-opératoire', 'Antibiotiques et anti-inflammatoires prescrits', 'PERS005', 'TRA005');


/*table paiement*/

INSERT INTO paiement (id_paiement, id_acte, datePaiement, montant, id_acte_1)
VALUES ('PAI001', 'ACT001', TO_DATE('2023-01-15', 'YYYY-MM-DD'), '120.50', 'ACT001');

INSERT INTO paiement (id_paiement, id_acte, datePaiement, montant, id_acte_1)
VALUES ('PAI002', 'ACT002', TO_DATE('2023-03-01', 'YYYY-MM-DD'), '250.00', 'ACT002');

INSERT INTO paiement (id_paiement, id_acte, datePaiement, montant, id_acte_1)
VALUES ('PAI003', 'ACT003', TO_DATE('2023-07-30', 'YYYY-MM-DD'), '300.00', 'ACT003');

INSERT INTO paiement (id_paiement, id_acte, datePaiement, montant, id_acte_1)
VALUES ('PAI004', 'ACT004', TO_DATE('2023-03-28', 'YYYY-MM-DD'), '180.00', 'ACT004');

INSERT INTO paiement (id_paiement, id_acte, datePaiement, montant, id_acte_1)
VALUES ('PAI005', 'ACT005', TO_DATE('2023-10-10', 'YYYY-MM-DD'), '1500.00', 'ACT005');


/*table franchise*/

INSERT INTO franchise (id_franchise, nom, adresse, telephone)
VALUES ('FRAN001', 'Franchise Dentaire Paris', '123 Rue de la Santé, 75000 Paris', '01 45 67 89 01');

INSERT INTO franchise (id_franchise, nom, adresse, telephone)
VALUES ('FRAN002', 'Franchise Dentaire Lyon', '45 Boulevard des Belges, 69000 Lyon', '04 72 33 44 55');

INSERT INTO franchise (id_franchise, nom, adresse, telephone)
VALUES ('FRAN003', 'Franchise Dentaire Marseille', '67 Avenue du Prado, 13008 Marseille', '04 91 25 35 45');

INSERT INTO franchise (id_franchise, nom, adresse, telephone)
VALUES ('FRAN004', 'Franchise Dentaire Lille', '9 Rue des Arts, 59000 Lille', '03 20 54 12 23');

INSERT INTO franchise (id_franchise, nom, adresse, telephone)
VALUES ('FRAN005', 'Franchise Dentaire Toulouse', '32 Place du Capitole, 31000 Toulouse', '05 61 23 45 67');


/*table equipement*/

INSERT INTO equipement (id_equipement, nom, description, quantite, coutUtilisation)
VALUES ('EQP001', 'Chaise dentaire', 'Chaise réglable pour patient avec appui-tête et repose-pieds.', '20', 150.00);

INSERT INTO equipement (id_equipement, nom, description, quantite, coutUtilisation)
VALUES ('EQP002', 'Radiographie panoramique', 'Appareil de radiographie pour réaliser des clichés panoramiques de la bouche.', '5', 500.00);

INSERT INTO equipement (id_equipement, nom, description, quantite, coutUtilisation)
VALUES ('EQP003', 'Scalpel chirurgical', 'Scalpel stérile utilisé pour les interventions chirurgicales dentaires.', '100', 20.00);

INSERT INTO equipement (id_equipement, nom, description, quantite, coutUtilisation)
VALUES ('EQP004', 'Blanchisseur dentaire', 'Appareil utilisé pour le blanchiment des dents avec gel professionnel.', '10', 200.00);

INSERT INTO equipement (id_equipement, nom, description, quantite, coutUtilisation)
VALUES ('EQP005', 'Lampe LED dentaire', 'Lampe LED pour éclairer les zones de travail pendant les traitements dentaires.', '15', 75.00);


/*table dent*/

INSERT INTO dent (id_dent, id_patient, codeFDI, id_patient_1)
VALUES ('DENT001', 'PAT001', '11', 'PAT001');  -- Dent 11 (incisive supérieure droite) du patient PAT001

INSERT INTO dent (id_dent, id_patient, codeFDI, id_patient_1)
VALUES ('DENT002', 'PAT001', '12', 'PAT001');  -- Dent 12 (incisive supérieure gauche) du patient PAT001

INSERT INTO dent (id_dent, id_patient, codeFDI, id_patient_1)
VALUES ('DENT003', 'PAT002', '21', 'PAT002');  -- Dent 21 (incisive inférieure droite) du patient PAT002

INSERT INTO dent (id_dent, id_patient, codeFDI, id_patient_1)
VALUES ('DENT004', 'PAT002', '22', 'PAT002');  -- Dent 22 (incisive inférieure gauche) du patient PAT002

INSERT INTO dent (id_dent, id_patient, codeFDI, id_patient_1)
VALUES ('DENT005', 'PAT003', '31', 'PAT003');  -- Dent 31 (incisive inférieure droite) du patient PAT003

INSERT INTO dent (id_dent, id_patient, codeFDI, id_patient_1)
VALUES ('DENT006', 'PAT003', '32', 'PAT003');  -- Dent 32 (incisive inférieure gauche) du patient PAT003

INSERT INTO dent (id_dent, id_patient, codeFDI, id_patient_1)
VALUES ('DENT007', 'PAT004', '41', 'PAT004');  -- Dent 41 (incisive supérieure droite) du patient PAT004

INSERT INTO dent (id_dent, id_patient, codeFDI, id_patient_1)
VALUES ('DENT008', 'PAT004', '42', 'PAT004');  -- Dent 42 (incisive supérieure gauche) du patient PAT004

INSERT INTO dent (id_dent, id_patient, codeFDI, id_patient_1)
VALUES ('DENT009', 'PAT005', '51', 'PAT005');  -- Dent 51 (incisive supérieure droite) du patient PAT005

INSERT INTO dent (id_dent, id_patient, codeFDI, id_patient_1)
VALUES ('DENT010', 'PAT005', '52', 'PAT005');  -- Dent 52 (incisive supérieure gauche) du patient PAT005


/*table etatDent*/

INSERT INTO etatDent (id_etatDent, id_dent, dateObservation, anomalies, restaurations, id_dent_1)
VALUES ('ETAT001', 'DENT001', TO_DATE('2023-02-10', 'YYYY-MM-DD'), 'Aucune anomalie', 'Plombage', 'DENT001');  -- Dent 11 de PAT001

INSERT INTO etatDent (id_etatDent, id_dent, dateObservation, anomalies, restaurations, id_dent_1)
VALUES ('ETAT002', 'DENT002', TO_DATE('2023-03-15', 'YYYY-MM-DD'), 'Carie légère', 'Plombage en résine', 'DENT002');  -- Dent 12 de PAT001

INSERT INTO etatDent (id_etatDent, id_dent, dateObservation, anomalies, restaurations, id_dent_1)
VALUES ('ETAT003', 'DENT003', TO_DATE('2023-04-05', 'YYYY-MM-DD'), 'Aucune anomalie', 'Aucune', 'DENT003');  -- Dent 21 de PAT002

INSERT INTO etatDent (id_etatDent, id_dent, dateObservation, anomalies, restaurations, id_dent_1)
VALUES ('ETAT004', 'DENT004', TO_DATE('2023-05-20', 'YYYY-MM-DD'), 'Carie modérée', 'Plombage en amalgame', 'DENT004');  -- Dent 22 de PAT002

INSERT INTO etatDent (id_etatDent, id_dent, dateObservation, anomalies, restaurations, id_dent_1)
VALUES ('ETAT005', 'DENT005', TO_DATE('2023-06-10', 'YYYY-MM-DD'), 'Aucune anomalie', 'Aucune', 'DENT005');  -- Dent 31 de PAT003

INSERT INTO etatDent (id_etatDent, id_dent, dateObservation, anomalies, restaurations, id_dent_1)
VALUES ('ETAT006', 'DENT006', TO_DATE('2023-07-22', 'YYYY-MM-DD'), 'Carie importante', 'Couronne métallique', 'DENT006');  -- Dent 32 de PAT003

INSERT INTO etatDent (id_etatDent, id_dent, dateObservation, anomalies, restaurations, id_dent_1)
VALUES ('ETAT007', 'DENT007', TO_DATE('2023-08-15', 'YYYY-MM-DD'), 'Anomalie de développement', 'Aucune', 'DENT007');  -- Dent 41 de PAT004

INSERT INTO etatDent (id_etatDent, id_dent, dateObservation, anomalies, restaurations, id_dent_1)
VALUES ('ETAT008', 'DENT008', TO_DATE('2023-09-05', 'YYYY-MM-DD'), 'Aucune anomalie', 'Plombage léger', 'DENT008');  -- Dent 42 de PAT004

INSERT INTO etatDent (id_etatDent, id_dent, dateObservation, anomalies, restaurations, id_dent_1)
VALUES ('ETAT009', 'DENT009', TO_DATE('2023-10-01', 'YYYY-MM-DD'), 'Aucune anomalie', 'Aucune', 'DENT009');  -- Dent 51 de PAT005

INSERT INTO etatDent (id_etatDent, id_dent, dateObservation, anomalies, restaurations, id_dent_1)
VALUES ('ETAT010', 'DENT010', TO_DATE('2023-11-12', 'YYYY-MM-DD'), 'Carie légère', 'Plombage composite', 'DENT010');  -- Dent 52 de PAT005


/*table anomalie*/

INSERT INTO anomalie (id_anomalie, type, description, gravite, id_etatDent)
VALUES ('ANOM001', 'Carie', 'Carie légère sur la dent 11', 'Moyenne', 'ETAT001');  -- Dent 11 (PAT001)

INSERT INTO anomalie (id_anomalie, type, description, gravite, id_etatDent)
VALUES ('ANOM002', 'Carie', 'Carie modérée sur la dent 12', 'Moyenne', 'ETAT002');  -- Dent 12 (PAT001)

INSERT INTO anomalie (id_anomalie, type, description, gravite, id_etatDent)
VALUES ('ANOM003', 'Anomalie de développement', 'Dent malformée, déviation de la racine', 'Haute', 'ETAT007');  -- Dent 41 (PAT004)

INSERT INTO anomalie (id_anomalie, type, description, gravite, id_etatDent)
VALUES ('ANOM004', 'Carie', 'Carie importante sur la dent 32', 'Haute', 'ETAT006');  -- Dent 32 (PAT003)

INSERT INTO anomalie (id_anomalie, type, description, gravite, id_etatDent)
VALUES ('ANOM005', 'Carie', 'Carie légère sur la dent 52', 'Moyenne', 'ETAT010');  -- Dent 52 (PAT005)



/*table restauration*/

INSERT INTO restauration (id_restauration, type, matériau, dureeDeVieEstimee, id_etatDent)
VALUES ('REST001', 'Plombage', 'Amalgame', '5 ans', 'ETAT001');  -- Dent 11 (PAT001)

INSERT INTO restauration (id_restauration, type, matériau, dureeDeVieEstimee, id_etatDent)
VALUES ('REST002', 'Plombage', 'Résine composite', '7 ans', 'ETAT002');  -- Dent 12 (PAT001)

INSERT INTO restauration (id_restauration, type, matériau, dureeDeVieEstimee, id_etatDent)
VALUES ('REST003', 'Couronne', 'Céramique', '10 ans', 'ETAT004');  -- Dent 22 (PAT002)

INSERT INTO restauration (id_restauration, type, matériau, dureeDeVieEstimee, id_etatDent)
VALUES ('REST004', 'Couronne', 'Métal précieux', '12 ans', 'ETAT006');  -- Dent 32 (PAT003)

INSERT INTO restauration (id_restauration, type, matériau, dureeDeVieEstimee, id_etatDent)
VALUES ('REST005', 'Plombage', 'Amalgame', '6 ans', 'ETAT008');  -- Dent 42 (PAT004)

INSERT INTO restauration (id_restauration, type, matériau, dureeDeVieEstimee, id_etatDent)
VALUES ('REST006', 'Facette', 'Céramique', '8 ans', 'ETAT010');  -- Dent 52 (PAT005)



/*association*/

-- Table d'association : appartient_a
-- Association de membres du personnel à des franchises

INSERT INTO appartient_a (id_personnel, id_franchise)
VALUES ('PERS001', 'FRAN001'); -- Michel Dupuis (Dentiste) travaille à la franchise Paris

INSERT INTO appartient_a (id_personnel, id_franchise)
VALUES ('PERS002', 'FRAN002'); -- Sophie Lefevre (Dentiste) travaille à la franchise Lyon

INSERT INTO appartient_a (id_personnel, id_franchise)
VALUES ('PERS003', 'FRAN003'); -- Julien Bernard (Chirurgien-dentiste) travaille à la franchise Marseille

INSERT INTO appartient_a (id_personnel, id_franchise)
VALUES ('PERS004', 'FRAN004'); -- Claire Marais (Chirurgien-dentiste) travaille à la franchise Lille

INSERT INTO appartient_a (id_personnel, id_franchise)
VALUES ('PERS005', 'FRAN005'); -- Thierry Chevalier (Chirurgien-dentiste) travaille à la franchise Toulouse

-- table comporte
-- TRA001 : Consultation initiale et radiographie
INSERT INTO comporte (id_traitement, id_produit)
VALUES ('TRA001', 'PROD002'); -- Fil dentaire utilisé lors de la consultation

-- TRA002 : Traitement des caries multiples
INSERT INTO comporte (id_traitement, id_produit)
VALUES ('TRA002', 'PROD001'); -- Brosse à dents électrique conseillée
INSERT INTO comporte (id_traitement, id_produit)
VALUES ('TRA002', 'PROD002'); -- Fil dentaire recommandé

-- TRA003 : Première séance de blanchiment
INSERT INTO comporte (id_traitement, id_produit)
VALUES ('TRA003', 'PROD003'); -- Dentifrice blanchissant utilisé
INSERT INTO comporte (id_traitement, id_produit)
VALUES ('TRA003', 'PROD005'); -- Kit de blanchiment inclus dans le traitement

-- TRA004 : Extraction de dent de sagesse
INSERT INTO comporte (id_traitement, id_produit)
VALUES ('TRA004', 'PROD004'); -- Gel de désinfection pour les gencives après l'extraction

-- TRA005 : Pose d'implant dentaire
INSERT INTO comporte (id_traitement, id_produit)
VALUES ('TRA005', 'PROD004'); -- Gel de désinfection utilisé lors de la pose
INSERT INTO comporte (id_traitement, id_produit)
VALUES ('TRA005', 'PROD001'); -- Brosse à dents électrique recommandée pour l'entretien

-- table est adressee a

INSERT INTO est_adressee_a (id_fournisseur, id_commande)
VALUES ('FOUR001', 'COM001'); -- Fournisseur Médical A est lié à la commande COM001

INSERT INTO est_adressee_a (id_fournisseur, id_commande)
VALUES ('FOUR002', 'COM002'); -- Fournisseur Médical B est lié à la commande COM002

INSERT INTO est_adressee_a (id_fournisseur, id_commande)
VALUES ('FOUR003', 'COM003'); -- Fournisseur Médical C est lié à la commande COM003

INSERT INTO est_adressee_a (id_fournisseur, id_commande)
VALUES ('FOUR004', 'COM004'); -- Fournisseur Médical D est lié à la commande COM004

INSERT INTO est_adressee_a (id_fournisseur, id_commande)
VALUES ('FOUR005', 'COM005'); -- Fournisseur Médical E est lié à la commande COM005


-- est fourni par

INSERT INTO est_fourni_par (id_produit, id_fournisseur)
VALUES ('PROD001', 'FOUR001'); -- Fournisseur Médical A fournit les brosses à dents électriques

INSERT INTO est_fourni_par (id_produit, id_fournisseur)
VALUES ('PROD002', 'FOUR002'); -- Fournisseur Médical B fournit le fil dentaire

INSERT INTO est_fourni_par (id_produit, id_fournisseur)
VALUES ('PROD003', 'FOUR003'); -- Fournisseur Médical C fournit le dentifrice blanchissant

INSERT INTO est_fourni_par (id_produit, id_fournisseur)
VALUES ('PROD004', 'FOUR004'); -- Fournisseur Médical D fournit le gel de désinfection

INSERT INTO est_fourni_par (id_produit, id_fournisseur)
VALUES ('PROD005', 'FOUR005'); -- Fournisseur Médical E fournit les kits de blanchiment




-- est possede par

INSERT INTO est_possede_par (id_franchise, id_equipement)
VALUES ('FRAN001', 'EQP001'); -- Chaise dentaire pour Franchise Paris

INSERT INTO est_possede_par (id_franchise, id_equipement)
VALUES ('FRAN001', 'EQP002'); -- Radiographie panoramique pour Franchise Paris

INSERT INTO est_possede_par (id_franchise, id_equipement)
VALUES ('FRAN002', 'EQP001'); -- Chaise dentaire pour Franchise Lyon

INSERT INTO est_possede_par (id_franchise, id_equipement)
VALUES ('FRAN002', 'EQP003'); -- Scalpel chirurgical pour Franchise Lyon

INSERT INTO est_possede_par (id_franchise, id_equipement)
VALUES ('FRAN003', 'EQP001'); -- Chaise dentaire pour Franchise Marseille

INSERT INTO est_possede_par (id_franchise, id_equipement)
VALUES ('FRAN003', 'EQP004'); -- Blanchisseur dentaire pour Franchise Marseille

INSERT INTO est_possede_par (id_franchise, id_equipement)
VALUES ('FRAN004', 'EQP001'); -- Chaise dentaire pour Franchise Lille

INSERT INTO est_possede_par (id_franchise, id_equipement)
VALUES ('FRAN004', 'EQP005'); -- Lampe LED pour Franchise Lille

INSERT INTO est_possede_par (id_franchise, id_equipement)
VALUES ('FRAN005', 'EQP001'); -- Chaise dentaire pour Franchise Toulouse

INSERT INTO est_possede_par (id_franchise, id_equipement)
VALUES ('FRAN005', 'EQP003'); -- Scalpel chirurgical pour Franchise Toulouse


COMMIT;