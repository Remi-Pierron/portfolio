import urllib.request
import bs4 
import pandas as pd
import re
import folium
import webbrowser
import time
import matplotlib.pyplot as plt  # Importation de matplotlib pour le traçage

start_time = time.time() 
# Fonction pour convertir des coordonnées DMS (Degrés, Minutes, Secondes) en degrés décimaux
def parse_dms(dms):
    if dms == "Non spécifiée":
        return None
    parts = re.split('[°\'"]', dms)
    try:
        degrees = float(parts[0])
        minutes = float(parts[1]) if len(parts) > 1 and parts[1] else 0
        seconds = float(parts[2]) if len(parts) > 2 and parts[2] else 0
        return degrees + minutes / 60 + seconds / 3600
    except (ValueError, IndexError) as e:
        print(f"Erreur de conversion pour les coordonnées {dms}: {e}")
        return None  # Valeur par défaut en cas d'erreur

# URL de la page à analyser
url = "https://fr.wikipedia.org/wiki/Mus%C3%A9e_de_France"
page = urllib.request.urlopen(url).read()
html = bs4.BeautifulSoup(page, "lxml")

musees = []
compteur = 0

for element in html.find_all('li'):
    lien = element.find('a')

    # Vérifie que le lien a les attributs 'title' et 'href'
    if lien and lien.has_attr('title') and lien.has_attr('href') and lien.text.lower().startswith("musée"):
        lieu = lien.text  # Nom du musée

        # Récupère la description
        description = element.get_text().split(":", 1)[1].strip() if ":" in element.get_text() else "Description non spécifiée"

        # Cherche le lien de la ville
        liens_ville = element.find_all('a')
        lien_ville = liens_ville[1] if len(liens_ville) > 1 else None

        if lien_ville and lien_ville.has_attr('href'):
            ville = lien_ville.text  # Nom de la ville
            url_ville = "https://fr.wikipedia.org/" + lien_ville['href']
            # Télécharge et analyse la page de la ville pour les coordonnées
            ville_page = urllib.request.urlopen(url_ville).read()
            ville_html = bs4.BeautifulSoup(ville_page, "lxml")
            coord_div = ville_html.find('div', {'id': 'mw-indicator-coordinates'})

            if coord_div:
                # Extraction de latitude et longitude
                lien_coordonnees = coord_div.find('a', {'class': 'mw-kartographer-maplink'})
                latitude = lien_coordonnees['data-lat'] if lien_coordonnees else "Non spécifiée"
                longitude = lien_coordonnees['data-lon'] if lien_coordonnees else "Non spécifiée"
            else:
                latitude = "Non spécifiée"
                longitude = "Non spécifiée"

            # Ajoute le musée, la description, la ville, et les coordonnées dans la liste
            musees.append((lieu, description, ville, latitude, longitude))

        compteur += 1  # Incrémente le compteur
        if compteur >= 20:
             break

print("Nombre de musées trouvés :", len(musees))

# Création d'un DataFrame avec les données
df_musees = pd.DataFrame(musees, columns=["Lieu", "Description", "ville", "latitude", "longitude"])

df_communes = pd.read_csv("cities.csv", delimiter=";", encoding="ISO-8859-1")


# Normalisation des noms de villes
df_musees['ville'] = df_musees['ville'].str.lower().str.strip()
df_communes['ville'] = df_communes['ville'].str.lower().str.strip()

df_musees_communes = pd.merge(df_musees, df_communes, on="ville", how="left")

df_musees_communes['departement'] = df_musees_communes['departement'].fillna("Département non trouvé")

# Comptage du nombre de musées par département
nombre_musees_par_departement = df_musees_communes['departement'].value_counts()

nombre_musees_par_departement = nombre_musees_par_departement[nombre_musees_par_departement.index != "Département non trouvé"]
nombre_musees_par_departement = nombre_musees_par_departement[nombre_musees_par_departement > 0]

# Création d'un graphique à barres
plt.figure(figsize=(12, 6))
nombre_musees_par_departement.plot(kind='bar', color='skyblue')
plt.title("Nombre de musées par département")
plt.xlabel("Département")
plt.ylabel("Nombre de musées")
plt.xticks(rotation=45, ha='right')
plt.tight_layout()  # Ajuste le layout pour que tout soit bien visible
plt.grid(axis='y')

#Sauvegarde et affichage du graphique
plt.savefig("nb_musees_dep.png", dpi=300, bbox_inches='tight')

# Affiche le graphique
plt.show()

# Créez une carte centrée sur la France
carteFrance = folium.Map(location=[47, 4], zoom_start=6)

# Parcours du DataFrame
for i in range(len(df_musees)):
    latitude = df_musees.iloc[i]['latitude']
    longitude = df_musees.iloc[i]['longitude']

    # Vérifiez que les coordonnées ne sont pas "None" ou "Non spécifiée"
    if latitude and longitude and latitude != "Non spécifiée" and longitude != "Non spécifiée":
        message_popup = f"<b>{df_musees.iloc[i]['Lieu']}</b><br>{df_musees.iloc[i]['Description']}<br>{df_musees.iloc[i]['ville']}"
        folium.Marker([latitude, longitude], popup=folium.Popup(message_popup, max_width=200)).add_to(carteFrance) 


end_time = time.time()  # End timer
execution_time = end_time - start_time
print(f"Execution time: {execution_time:.2f} seconds")

# Enregistrer la carte
carteFrance.save('musees_france.html')
