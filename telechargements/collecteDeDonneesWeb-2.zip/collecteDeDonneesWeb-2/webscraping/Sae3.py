import urllib.request
import csv
import bs4 
import pandas as pd
import re
import folium
import webbrowser
import time
import matplotlib.pyplot as plt  # Importation de matplotlib pour le traçage

start_time = time.time() 


# URL de la page à analyser
url = "https://fr.wikipedia.org/wiki/Mus%C3%A9e_de_France"
page = urllib.request.urlopen(url).read()
html = bs4.BeautifulSoup(page, "lxml")


#Recuperer le code de la table
table = None
for t in html.find_all('table'):
    if t.get('class') == ['wikitable']:
        table = t
        break



# Vérifier si la table a été trouvée
if table:
    # Récupérer toutes les lignes de la table
    rows = table.find_all('tr')

    # Extraire le contenu de chaque cellule
    data = []
    for row in rows:
        cells = row.find_all(['td', 'th'])  # Inclure aussi les headers si besoin
        cell_data = [cell.get_text(strip=True) for cell in cells]
        data.append(cell_data)

    # Créer un DataFrame pandas avec les données récupérées
    df = pd.DataFrame(data[1:], columns=data[0])  # En supposant que la première ligne est l'en-tête
    
    # Afficher le DataFrame
    print(df)
else:
    print("Table avec la classe 'Wikitable' non trouvée.")
 
#remplacer les valeurs manquante par 0 et enleve les espaces    
years = df.columns[2:] 
df[years] = df[years].replace({'fermé': 0, '': 0, None: 0})
df[years] = df[years].replace(r'\s+', '', regex=True)

df[years] = df[years].apply(pd.to_numeric, errors='coerce')

# # Calculer le total des visiteurs par année
total_visitors_per_year = df[years].sum()


# # Afficher les totaux par année
print("\nTotal des visiteurs par année :")
print(total_visitors_per_year)

# Tracer le graphique de l'évolution
plt.figure(figsize=(10, 6))
plt.plot(total_visitors_per_year.index, total_visitors_per_year.values, marker='o', linestyle='-')
plt.xlabel("Année")
plt.ylabel("Nombre total de visiteurs")
plt.title("Évolution du nombre total de visiteurs sur tous les musées")
plt.xticks(rotation=45)  
plt.grid()
plt.tight_layout()  

#Sauvegarde et affichage du graphique
plt.savefig("musee_freq.png", dpi=300, bbox_inches='tight')
plt.show()


