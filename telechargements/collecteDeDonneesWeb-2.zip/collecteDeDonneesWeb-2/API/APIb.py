
import requests
import pandas as pd
import folium
from tqdm import tqdm  #Utilisé pour la barre de progression




#Récupération des données DPE avec gestion des différentes pages
def get_dpe_data(insee_code): #Prend en entrée le code insee de la ville
    #Parmètres de la base d'où sont tiré les données
    base_url = "https://data.ademe.fr/data-fair/api/v1/datasets/dpe-france/lines"
    params = {
        "format": "json",
        "qs": insee_code,
    }

    #Obtention du nombre total d'enregistrement
    response = requests.get(base_url, params=params)
    if response.status_code == 200:
        initial_data = response.json()
        total_results = initial_data['total']  #Nombre total de résultats
        print(f"Nombre total d'enregistrements : {total_results}")

        all_results = initial_data['results']  #Ajout des résultats précédents

        #Récupération des pages suivantes et avancement de la barre de progression
        next_url = initial_data.get('next')
        for _ in tqdm(range(1, total_results), desc="Traitement des logements", unit="logement"):
            if next_url: #Si la prochaine URL de page existe
                response = requests.get(next_url)
                if response.status_code == 200:
                    data = response.json()
                    all_results.extend(data['results'])
                    next_url = data.get('next')
                else:
                    print(f"Erreur lors de la récupération de la page suivante: {response.status_code}")
                    break

        #Convertion en dataframe et suppression des colonnes inutile
        df = pd.DataFrame(all_results) if all_results else None
        if df is not None:
            #Filtrage des colonnes
            columns_to_keep = ['geo_adresse', 'date_etablissement_dpe', 'latitude', 'longitude', 
                               'consommation_energie', 'estimation_ges', 'classe_consommation_energie']
            df = df[columns_to_keep]
        
        #Renvoie le dataframe
        return df
    else:
        #Retourne un message si il y a une erreur
        print(f"Erreur: {response.status_code}")
        return None



#Traitement du dataframe
def process_dataframe(df):
    #Suppression des lignes avec des valeurs manquantes
    df = df.dropna(subset=['latitude', 'longitude'])
    
    if df.empty:
        #Renvoie un message d'erreur si le dataframe est vide
        print("Aucune donnée valide après suppression des valeurs manquantes.")
        return df

    #Convertion de 'date_etablissement_dpe' en datetime et garder la plus récente
    df.loc[:, 'date_etablissement_dpe'] = pd.to_datetime(df['date_etablissement_dpe'], errors='coerce')
    df = df.loc[df.groupby('geo_adresse')['date_etablissement_dpe'].idxmax()]

    #Triage par date d'établissement DPE décroissante
    df.sort_values(by='date_etablissement_dpe', ascending=False, inplace=True)
    
    #Renvoie le dataframe
    return df



#Determination de la couleur du marqueur par classe énergétique
def get_marker_color(energy_class): #Prend en entrée la classe énergétique
    color_map = {
        'A': 'green',
        'B': 'lightgreen',
        'C': 'orange',
        'D': 'darkorange',
        'E': 'red',
        'F': 'darkred',
        'G': 'black'
    }
    return color_map.get(energy_class, 'blue')  #Affecte la couleur, blue par défaut



#Création de la carte folium
def create_map(df): #Prend le dataframe déja traité en entrée
    if df.empty:
        #Renvoie un message d'erreur si le dataframe est vide
        print("Aucune donnée valide pour créer des marqueurs.")
        return None

    #Création d'une carte centrée sur la moyenne des coordonnées
    map_center = [df['latitude'].mean(), df['longitude'].mean()]
    m = folium.Map(location=map_center, zoom_start=13)

    #Ajout d'un marqueurs pour chaque logement
    for _, row in df.iterrows():
        folium.Marker(
            location=[row['latitude'], row['longitude']],
            popup=( #Champs de l'étiquette du marqueur
                f"<strong>Adresse:</strong> {row.get('geo_adresse', 'Adresse non disponible')}<br>"
                f"<strong>Consommation:</strong> {row.get('consommation_energie', 'Consommation non disponible')} kWh/m²<br>"
                f"<strong>Émissions:</strong> {row.get('estimation_ges', 'Émissions non disponibles')} kgCO₂/m²<br>"
                f"<strong>Classe énergétique:</strong> {row.get('classe_consommation_energie', 'Classe non disponible')}"
            ),
            icon=folium.Icon(color=get_marker_color(row.get('classe_consommation_energie', 'Classe non disponible'))) #Association d'une couleur au marqueur
        ).add_to(m)
    
    #Renvoie la carte avec les ajouts de marqueur
    return m




#Demande le code Insee à l'utilisateur
insee_code = input("Entrez le code Insee de la commune (ex: 79125 pour Fors) : ")


#Récupération des data correspondant au code Insee via get_dpe_data
data_df = get_dpe_data(insee_code)


#Traitement du dataframe pour trier les données
if data_df is not None and not data_df.empty:
    #Trie du dataframe via process_dataframe
    sorted_df = process_dataframe(data_df)
    
    #Création et affichage de la carte
    dpe_map = create_map(sorted_df)
    if dpe_map is not None: #Si le dataframe est trouvable, alors : enregistrement de la carte dans un fichier html
        dpe_map.save("carte_dpe.html")
        print("La carte a été créée et enregistrée sous le nom 'carte_dpe.html'. Ouvrez ce fichier pour voir la carte.")
else:
    #Renvoie un message d'erreur si le dataframe est vide ou introuvable
    print("Aucune donnée disponible pour ce code Insee.")