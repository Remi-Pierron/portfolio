import requests
import pandas as pd
import matplotlib.pyplot as plt
from tqdm import tqdm
import numpy as np




#Codes Insee correspondant aux villes à analyser
villes = {
    "Sainte-Soline": "79294",
    "Massignac": "16148",
    "Le Fouilloux": "17166",
    "Ars-en-Ré": "17019"
}



#Récupération des données DPE avec gestion des différentes pages
def recuperer_dpe_ville(code_insee):    #Prend en entrée le code insee de la ville
    #Parmètres de la base d'où sont tiré les données
    url = f"https://data.ademe.fr/data-fair/api/v1/datasets/dpe-france/lines?format=json&qs={code_insee}"
    resultats = []
    
    #Obtention du nombre total d'éléments
    response = requests.get(url)
    data = response.json()
    total_logements = data['total']
    
    #Initialisation de la barre de progression
    with tqdm(total=total_logements, desc=f"Chargement pour {code_insee}") as pbar:
        while url:
            #Requête pour récupérer les données
            response = requests.get(url)
            data = response.json()
            
            #Ajout des résultats de la page actuelle
            resultats.extend(data['results'])
            
            #Mise à jour de la barre de progression
            pbar.update(len(data['results']))
            
            #Passage à la page suivante si possible
            url = data.get("next")

    #Transformation des résultats en dataframe
    logements = pd.DataFrame(resultats)
    
    #Filtrage des logements les plus récent en supprimant les doublons (latitude, longitude)
    logements = logements.sort_values("date_etablissement_dpe", ascending=False).drop_duplicates(subset=["latitude", "longitude"])
    
    #Renvoie les colonnes de l'année de construction et de la classe de consommation d'énergie
    return logements[['annee_construction', 'classe_consommation_energie']]



#Création d'un dataframe pour stocker les pourcentages par lettre pour chaque ville
df_dpe = pd.DataFrame()


#Boucle de récupération des données pour chaque ville, qui pour chacune, va chercher les informations via recuperer_dpe_ville puis les regroupent
for ville, code_insee in villes.items():
    df_ville = recuperer_dpe_ville(code_insee)  #Récupération des données pour la ville
    df_ville['ville'] = ville   #Ajout d'une colonne pour la ville
    df_dpe = pd.concat([df_dpe, df_ville], ignore_index=True)   #Ajout des données de la ville au reste des données


#Groupement des données par décennie
df_dpe['decennie_construction'] = (df_dpe['annee_construction'] // 10) * 10     #Création d'une classe correspondant à la décennie de construction
df_grouped = df_dpe.groupby(['decennie_construction', 'classe_consommation_energie']).size().unstack().fillna(0)    #Regroupement par la décennie de construction puis la classe consomation d'énergie


#Groupement des données par classe énergétique
classes_energetiques = ['A', 'B', 'C', 'D', 'E', 'F', 'G']
df_grouped = df_grouped.reindex(columns=classes_energetiques, fill_value=0)


#Création du graphique en barre groupées
fig, ax = plt.subplots(figsize=(12, 8))
width = 0.1
x = np.arange(len(df_grouped.index))


#Création de la palette de couleur pour les classes énergétique de A à G
colors = ["#00FF00", "#7FFF00", "#FFFF00", "#FFBF00", "#FF8000", "#FF4000", "#FF0000"]


#Boucle qui trace pour chaque classe énergétique (A à G) pour chaque décénnie avec la couleur correspondante
for i, classe in enumerate(classes_energetiques):
    ax.bar(x + i * width, df_grouped[classe], width, label=classe, color=colors[i])


#Configuration des étiquettes et axes du graphique
ax.set_xlabel("Décennie de construction")
ax.set_ylabel("Nombre de logements")
ax.set_title("Répartition des classes énergétiques par décennie de construction")
ax.set_xticks(x + width * (len(classes_energetiques) - 1) / 2)
ax.set_xticklabels(df_grouped.index.astype(int))
ax.legend(title="Classe énergétique")


#Sauvegarde et affichage du graphique
plt.savefig("repartition_dpe_par_decennie.png", dpi=300, bbox_inches='tight')
plt.show()