import requests
import pandas as pd
import matplotlib.pyplot as plt
from tqdm import tqdm #Utilisé pour la barre de progression
from matplotlib.colors import LinearSegmentedColormap
import numpy as np




#Codes Insee correspondant aux villes à analyser
villes = {
    "La Rochelle": "17000",
    "Angouleme": "16000",
    "Niort": "79000",
    "Poitiers": "86000"
}



#Récupération des données DPE avec gestion des différentes pages
def recuperer_dpe_ville(code_insee): #Prend en entrée le code insee de la ville
    #Parmètres de la base d'où sont tiré les données
    url = f"https://data.ademe.fr/data-fair/api/v1/datasets/dpe-france/lines?format=json&qs={code_insee}"
    resultats = []

    #Obtention du nombre total d'éléments
    response = requests.get(url)
    data = response.json()
    total_logements = data['total']
    
    #Initialisation de la barre de progression
    with tqdm(total=total_logements, desc=f"Chargement pour {code_insee}") as pbar:
        while url:
            #Requête pour récupérer les données
            response = requests.get(url)
            data = response.json()
            
            #Ajout des résultats de la page actuelle
            resultats.extend(data['results'])
            
            #Mise à jour de la barre de progression
            pbar.update(len(data['results']))
            
            #Passage à la page suivante si possible
            url = data.get("next")

    #Transformation des résultats en dataframe
    logements = pd.DataFrame(resultats)
    
    #Filtrage des logements les plus récent en supprimant les doublons (latitude, longitude)
    logements = logements.sort_values("date_etablissement_dpe", ascending=False).drop_duplicates(subset=["latitude", "longitude"])

    #Calcul du pourcentage de logement par lettre de DPE
    lettres_dpe = ['A', 'B', 'C', 'D', 'E', 'F', 'G']
    if 'classe_consommation_energie' in logements.columns:
        #Renvoie le calcul donnant le pourcentage de logement par lettre de DPE si la classe de consommation énergétique existe dans logement
        return logements['classe_consommation_energie'].value_counts(normalize=True).reindex(lettres_dpe, fill_value=0) * 100
    else:
        #Renvoie un message d'erreur si la classe énergétique n'existe pas dans logement
        print(f"'classe_consommation_energie' n'est pas disponible pour le code INSEE {code_insee}.")
        return pd.Series(dtype='float64')   #Renvoie une série vide



#Création d'un dataframe pour stocker les pourcentages par lettre pour chaque ville
df_dpe = pd.DataFrame()


#Boucle de récupération des données pour chaque ville qui pour chaques villes de la liste, va chercher les informations via recuperer_dpe_ville
for ville, code_insee in villes.items():
    df_dpe[ville] = recuperer_dpe_ville(code_insee)


#Transposition du dataframe pour que chaque lettre soit une colonne unique pour chaque ville
df_dpe = df_dpe.T[["A", "B", "C", "D", "E", "F", "G"]]


#Mise en place d'un dégradé de couleur, du vert (A) au rouge (G)
colors = LinearSegmentedColormap.from_list("DPE", ["green", "orange", "red"], N=7)
color_map = [colors(i/6) for i in range(7)]  #Création des couleurs pour les lettres de A à G


#Création du graphique en barre avec 6 barres distinctes pour chaque ville
fig, ax = plt.subplots(figsize=(10, 6))
x = np.arange(len(df_dpe))  #Position de chaque ville sur l'axe des x
width = 0.1


#Boucle qui trace pour chaque lettre de DPE (A à G) pour chaque ville avec la couleur correspondante
for i, letter in enumerate(["A", "B", "C", "D", "E", "F", "G"]):
    ax.bar(x + i*width, df_dpe[letter], width, label=letter, color=color_map[i])


#Configuration des étiquettes et axes du graphique
ax.set_xlabel("Villes")
ax.set_ylabel("Pourcentage de logements (%)")
ax.set_title("Répartition du DPE par lettre pour les principales villes de Poitou-Charentes")
ax.set_xticks(x + width*3)
ax.set_xticklabels(df_dpe.index)
ax.legend(title="DPE Lettre", loc="upper left", bbox_to_anchor=(1, 1))


#Sauvegarde et affichage du graphique
plt.savefig("repartition_DPE_villes.png", format="png", dpi=300, bbox_inches="tight")
plt.show()