Le fichier APIb.py sert à créer la carte folium. Attention à préciser le code postal de la ville à représenter sur la carte.

Le fichier APIc.py traite de la création du graphique qui représente la repartion des lettres energetiques en fonction des différentes grandes villes.
Ce code s'éxécute en plus de 15 min, c'est pour cela que nous avons dupliqué ce code avec APIc2.py avec des petites villes afin d'éxécuter le code plus rapidement.

Le fichier APId.py permet de créer le graphique avec les indicateurs libres. 
Nous avons choisi de représenter les lettres énergétiques en fonction de la décennie de construction des habitation.
Nous avons réutilisé le jeu de données de APIc2.py.