Bienvenue sur le logiciel de collecte de données web.

Les fichiers sont organisés comme ceci :

Le dossier API contient les programmes python liés à l'API.
Le dossier webscraping contient les programmes python liés au webscraping.
Le dossier appWeb contient les différentes pages web ainsi que les données (cartes, graphiques, ...) issus des programmes python.

Il est nécessaire d'insaller les librairies python suivantes :

- folium
- tqdm (utile pour afficher les barres de progressions du chargement des données pour s'assurer que le programme fonctionne)
- requests