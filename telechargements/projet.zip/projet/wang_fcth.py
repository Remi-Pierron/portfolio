import pandas as pd
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix, accuracy_score, classification_report, roc_curve, auc
from sklearn.preprocessing import StandardScaler, label_binarize
import seaborn as sns
import matplotlib.pyplot as plt

# ==========================================
# 1. IMPORTATION ET PRÉPARATION SÉCURISÉE
# ==========================================
print("Chargement des données...")

# 1. Chargement du fichier Excel
xls_file = 'WangSignatures.xls'
# header=None car le fichier ne contient pas de ligne de titres
df = pd.read_excel(xls_file, header=None)

# 2. SÉPARATION STRICTE : NOMS vs DESCRIPTEURS
filenames = df.iloc[:, 0].values

# La variable X ne doit contenir QUE les chiffres (les descripteurs)
# On prend de la colonne 1 (incluse) jusqu'à la fin.
X = df.iloc[:, 1:].values

print(f"--> Colonne des noms (exclue) : {filenames[0]} ...")
print(f"--> Dimensions de X : {X.shape}")

# 3. CRÉATION DES LABELS (VÉRITÉ TERRAIN)
y = []
for fname in filenames:
    # Nettoyage du nom (ex: "105.jpg" -> 105)
    clean_name = str(fname).lower().replace('.jpg', '').strip()
    try:
        img_id = int(clean_name)
        # La classe est la centaine (ex: 105 // 100 = 1)
        label = img_id // 100
        y.append(label)
    except ValueError:
        print(f"Erreur de lecture du fichier : {fname}")

y = np.array(y)
print(f"--> Labels générés : {len(y)} (Classes : {np.unique(y)})")

# ==========================================
# 2. PRÉPARATION STRATIFIÉE POUR L'IA
# ==========================================
# MODIFICATION ICI : Ajout de 'stratify=y'
# Cela force la distribution des classes dans le train et le test à être identiques à l'original
X_train, X_test, y_train, y_test = train_test_split(
    X, y, 
    test_size=0.2, 
    random_state=42, 
    stratify=y  # <--- C'est ici que la magie opère
)

print(f"--> Train set : {X_train.shape[0]} images")
print(f"--> Test set  : {X_test.shape[0]} images (équilibré par classe)")

# Normalisation (StandardScaler)
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# ==========================================
# 3. LE MODÈLE (PERCEPTRON)
# ==========================================
model = Sequential()

# Couches
model.add(Dense(128, activation='relu', input_shape=(X_train.shape[1],)))
model.add(Dropout(0.3)) 

model.add(Dense(64, activation='relu'))
model.add(Dropout(0.3))

model.add(Dense(10, activation='softmax'))

# Compilation
model.compile(optimizer='adam',
              loss='sparse_categorical_crossentropy',
              metrics=['accuracy'])

# ==========================================
# 4. ENTRAÎNEMENT
# ==========================================
print("\nLancement de l'entraînement...")
# Note : validation_split prend les 10% de la fin des données d'entraînement.
# Comme train_test_split a mélangé les données (shuffle=True par défaut), 
# la validation sera aussi aléatoire.
history = model.fit(X_train, y_train, 
                    epochs=50, 
                    batch_size=32, 
                    validation_split=0.1, 
                    verbose=1)

# ==========================================
# 5. ANALYSE DES RÉSULTATS
# ==========================================
print("\n--- RÉSULTATS FINAUX ---")
y_pred_prob = model.predict(X_test)
y_pred = np.argmax(y_pred_prob, axis=1)

acc = accuracy_score(y_test, y_pred)
print(f"Précision (Accuracy) : {acc:.2%}")
print(f"Taux d'erreur        : {1-acc:.2%}")

# Affichage du rapport détaillé par classe
print("\n--- Rapport de Classification ---")
class_names = ['Jungle', 'Plage', 'Monuments', 'Bus', 'Dinos', 'Elephants', 'Fleurs', 'Chevaux', 'Montagne', 'Plats']
print(classification_report(y_test, y_pred, target_names=class_names))

# Matrice de confusion
plt.figure(figsize=(10, 8))
cm = confusion_matrix(y_test, y_pred)
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
            xticklabels=class_names,
            yticklabels=class_names)
plt.title(f'Matrice de Confusion (Stratifiée)\nAccuracy: {acc:.2%}')
plt.xlabel('Prédiction')
plt.ylabel('Vrai Label')
plt.show()

# Fonction pour créer un modèle avec des hyperparamètres spécifiques
def create_model(hidden_units_1, hidden_units_2, dropout_rate, optimizer):
    model = Sequential()
    model.add(Dense(hidden_units_1, activation='relu', input_shape=(X_train.shape[1],)))
    model.add(Dropout(dropout_rate))
    model.add(Dense(hidden_units_2, activation='relu'))
    model.add(Dropout(dropout_rate))
    model.add(Dense(10, activation='softmax'))
    model.compile(optimizer=optimizer,
                  loss='sparse_categorical_crossentropy',
                  metrics=['accuracy'])
    return model

# Définition des hyperparamètres pour les cinq modèles (tous plus lourds)
models_config = [
    {'hidden_units_1': 512, 'hidden_units_2': 256, 'dropout_rate': 0.4, 'optimizer': 'adam'},  # Modèle lourd
    {'hidden_units_1': 1024, 'hidden_units_2': 512, 'dropout_rate': 0.4, 'optimizer': 'adam'}, # Modèle très lourd
    {'hidden_units_1': 2048, 'hidden_units_2': 1024, 'dropout_rate': 0.5, 'optimizer': 'adam'},# Modèle encore plus lourd
    {'hidden_units_1': 4096, 'hidden_units_2': 2048, 'dropout_rate': 0.5, 'optimizer': 'adam'},# Modèle extrêmement lourd
    {'hidden_units_1': 8192, 'hidden_units_2': 4096, 'dropout_rate': 0.6, 'optimizer': 'adam'} # Modèle ultra lourd
]

# Entraînement et évaluation des cinq modèles
results = []
for i, config in enumerate(models_config):
    print(f"\nCréation et entraînement du modèle {i+1} avec les hyperparamètres : {config}")
    model = create_model(**config)
    history = model.fit(X_train, y_train, 
                        epochs=50, 
                        batch_size=64,  # Augmentation de la taille du batch pour s'adapter à des modèles plus lourds
                        validation_split=0.1, 
                        verbose=1)
    y_pred_prob = model.predict(X_test)
    y_pred = np.argmax(y_pred_prob, axis=1)
    accuracy = accuracy_score(y_test, y_pred)
    error_rate = 1 - accuracy
    results.append({'model': i+1, 'accuracy': accuracy, 'error_rate': error_rate})
    print(f"Modèle {i+1} - Précision : {accuracy:.2%}, Taux d'erreur : {error_rate:.2%}")

# Comparaison des résultats
print("\nComparaison des performances des modèles :")
for result in results:
    print(f"Modèle {result['model']} - Précision : {result['accuracy']:.2%}, Taux d'erreur : {result['error_rate']:.2%}")

# Sélection du meilleur modèle (celui avec l'accuracy la plus élevée)
best_model = max(results, key=lambda x: x['accuracy'])
print(f"\nLe meilleur modèle est le modèle {best_model['model']} avec une précision de {best_model['accuracy']:.2%}")

# Recréez et réentraînez le meilleur modèle pour afficher sa matrice de confusion
best_config = models_config[best_model['model'] - 1]
best_model_instance = create_model(**best_config)
best_model_instance.fit(X_train, y_train, 
                        epochs=50, 
                        batch_size=64, 
                        validation_split=0.1, 
                        verbose=0)  # Entraînement silencieux

# Prédictions du meilleur modèle
y_pred_prob_best = best_model_instance.predict(X_test)
y_pred_best = np.argmax(y_pred_prob_best, axis=1)

# Matrice de confusion du meilleur modèle
plt.figure(figsize=(10, 8))
cm_best = confusion_matrix(y_test, y_pred_best)
sns.heatmap(cm_best, annot=True, fmt='d', cmap='Blues',
            xticklabels=class_names,
            yticklabels=class_names)
plt.title(f'Matrice de Confusion du Meilleur Modèle (Modèle {best_model["model"]})\nAccuracy: {best_model["accuracy"]:.2%}')
plt.xlabel('Prédiction')
plt.ylabel('Vrai Label')
plt.show()

# Binarisation des labels pour calculer la courbe ROC multi-classes
y_test_binarized = label_binarize(y_test, classes=np.unique(y))
n_classes = y_test_binarized.shape[1]

# Calcul des probabilités pour chaque classe
y_score = best_model_instance.predict(X_test)

# Calcul des courbes ROC et des AUC pour chaque classe
fpr = {}
tpr = {}
roc_auc = {}
for i in range(n_classes):
    fpr[i], tpr[i], _ = roc_curve(y_test_binarized[:, i], y_score[:, i])
    roc_auc[i] = auc(fpr[i], tpr[i])

# Tracé de la courbe ROC pour chaque classe
plt.figure(figsize=(10, 8))
for i in range(n_classes):
    plt.plot(fpr[i], tpr[i], label=f'Classe {class_names[i]} (AUC = {roc_auc[i]:.2f})')

# Ajout de la courbe ROC moyenne (macro)
fpr["macro"], tpr["macro"], _ = roc_curve(y_test_binarized.ravel(), y_score.ravel())
roc_auc["macro"] = auc(fpr["macro"], tpr["macro"])
plt.plot(fpr["macro"], tpr["macro"], label=f'ROC Moyenne (macro) (AUC = {roc_auc["macro"]:.2f})', linestyle='--', color='navy')

# Ajout des détails au graphique
plt.plot([0, 1], [0, 1], 'k--', lw=2)
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('Taux de Faux Positifs (FPR)')
plt.ylabel('Taux de Vrais Positifs (TPR)')
plt.title(f'Courbe ROC pour le Meilleur Modèle (Modèle {best_model["model"]})')
plt.legend(loc="lower right")
plt.show()