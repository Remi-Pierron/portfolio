import os
import cv2
import numpy as np
import tensorflow as tf
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay, classification_report
from tensorflow.keras import layers, models, callbacks, regularizers, optimizers
import matplotlib.pyplot as plt

# ==========================================
# 1. CONFIGURATION
# ==========================================
DATA_DIR = "Wang"
IMG_SIZE = 256
NUM_CLASSES = 10
TOTAL_IMAGES = 1000
MAX_ATTEMPTS = 5        
SUCCESS_THRESHOLD = 0.60 

# Noms des classes pour les rapports
CLASS_NAMES = [
    "Jungle", "Plage", "Monuments", "Bus", "Dinosaures", 
    "Eléphants", "Fleurs", "Chevaux", "Montagne", "Plats"
]

print(f"GPUs disponibles: {tf.config.list_physical_devices('GPU')}")

# ==========================================
# 2. CHARGEMENT
# ==========================================
def load_data():
    images = []
    labels = []
    print("Chargement des images...")
    for i in range(TOTAL_IMAGES):
        img_path = os.path.join(DATA_DIR, f"{i}.jpg")
        img = cv2.imread(img_path)
        if img is not None:
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            img = cv2.resize(img, (IMG_SIZE, IMG_SIZE))
            img = img.astype('float32') / 255.0
            images.append(img)
            labels.append(i // 100)
    return np.array(images), np.array(labels)

X, y = load_data()

# ==========================================
# 3. STRATIFICATION
# ==========================================
X_main, X_test, y_main, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)
X_train, X_val, y_train, y_val = train_test_split(
    X_main, y_main, test_size=0.2, random_state=42, stratify=y_main
)

# ==========================================
# 4. MODÈLE V4 (High Capacity)
# ==========================================
def create_model_v4():
    model = models.Sequential()
    
    # Data Augmentation
    model.add(layers.Input(shape=(IMG_SIZE, IMG_SIZE, 3)))
    model.add(layers.RandomFlip("horizontal"))
    model.add(layers.RandomRotation(0.2))
    model.add(layers.RandomZoom(0.2))
    model.add(layers.RandomTranslation(0.1, 0.1))
    model.add(layers.RandomContrast(0.2))
    
    # CNN Profond
    model.add(layers.Conv2D(32, (3, 3), padding='same', kernel_regularizer=regularizers.l2(0.0005)))
    model.add(layers.BatchNormalization())
    model.add(layers.Activation('relu'))
    model.add(layers.MaxPooling2D((2, 2)))
    
    model.add(layers.Conv2D(64, (3, 3), padding='same', kernel_regularizer=regularizers.l2(0.0005)))
    model.add(layers.BatchNormalization())
    model.add(layers.Activation('relu'))
    model.add(layers.MaxPooling2D((2, 2)))
    
    model.add(layers.Conv2D(128, (3, 3), padding='same', kernel_regularizer=regularizers.l2(0.0005)))
    model.add(layers.BatchNormalization())
    model.add(layers.Activation('relu'))
    model.add(layers.MaxPooling2D((2, 2)))
    
    model.add(layers.Conv2D(256, (3, 3), padding='same', kernel_regularizer=regularizers.l2(0.0005)))
    model.add(layers.BatchNormalization())
    model.add(layers.Activation('relu'))
    model.add(layers.MaxPooling2D((2, 2)))
    
    # Classification
    model.add(layers.GlobalAveragePooling2D())
    model.add(layers.Dropout(0.5))
    model.add(layers.Dense(256, activation='relu', kernel_regularizer=regularizers.l2(0.0005)))
    model.add(layers.Dropout(0.5))
    model.add(layers.Dense(NUM_CLASSES, activation='softmax'))

    opt = optimizers.Adam(learning_rate=0.001)
    
    model.compile(optimizer=opt,
                  loss='sparse_categorical_crossentropy',
                  metrics=['accuracy'])
    return model

# ==========================================
# 5. FAIL FAST CALLBACK
# ==========================================
class FailFastCallback(callbacks.Callback):
    def __init__(self, threshold=0.25, epoch_check=30):
        super(FailFastCallback, self).__init__()
        self.threshold = threshold
        self.epoch_check = epoch_check

    def on_epoch_end(self, epoch, logs=None):
        if epoch == self.epoch_check:
            val_acc = logs.get('val_accuracy')
            if val_acc < self.threshold:
                print(f"\n[FailFast] Arrêt : Accuracy {val_acc:.2f} < {self.threshold}")
                self.model.stop_training = True

# ==========================================
# 6. BOUCLE D'ENTRAÎNEMENT (AUTO-RETRY)
# ==========================================
best_run_history = None
final_model = None
success = False

for attempt in range(1, MAX_ATTEMPTS + 1):
    print(f"\n{'='*40}\n TENTATIVE {attempt} / {MAX_ATTEMPTS}\n{'='*40}")
    tf.keras.backend.clear_session()
    model = create_model_v4()
    
    checkpoint_cb = callbacks.ModelCheckpoint(
        "best_wang_model.keras", monitor='val_accuracy', save_best_only=True, mode='max', verbose=0
    )
    reduce_lr = callbacks.ReduceLROnPlateau(monitor='val_loss', factor=0.2, patience=8, min_lr=1e-6)
    early_stopping = callbacks.EarlyStopping(monitor='val_loss', patience=30, restore_best_weights=True)
    fail_fast = FailFastCallback(threshold=0.25, epoch_check=30)

    try:
        history = model.fit(
            X_train, y_train,
            epochs=100,
            batch_size=32,
            validation_data=(X_val, y_val),
            callbacks=[checkpoint_cb, reduce_lr, early_stopping, fail_fast],
            verbose=1
        )
        
        best_val_acc = max(history.history['val_accuracy'])
        print(f"\n>> Meilleure Val Accuracy : {best_val_acc:.2%}")
        
        if best_val_acc >= SUCCESS_THRESHOLD:
            print(">>> SUCCÈS !")
            best_run_history = history
            final_model = model
            success = True
            break
            
    except Exception as e:
        print(f"Erreur : {e}")
        continue

if not success:
    print("\n/!\\ Attention : Seuil non atteint.")
    final_model = model

# ==========================================
# 7. ANALYSE COMPLÈTE & RAPPORT
# ==========================================
print("\n" + "="*40)
print("       RÉSULTATS DÉTAILLÉS")
print("="*40)

print("Chargement du meilleur modèle...")
try:
    final_model.load_weights("best_wang_model.keras")
    print("Poids chargés.")
except:
    print("Utilisation du modèle en mémoire.")

# 1. Évaluation Globale
loss, acc = final_model.evaluate(X_test, y_test, verbose=0)
print(f"\n>>> GLOBAL ACCURACY : {acc:.2%} <<<")

# 2. Prédictions
print("Génération des prédictions...")
y_pred_probs = final_model.predict(X_test)
y_pred = np.argmax(y_pred_probs, axis=1)

# 3. Rapport de Classification Textuel (Nouveau !)
print("\n--- Rapport de Classification ---")
report = classification_report(y_test, y_pred, target_names=CLASS_NAMES)
print(report)

# 4. Matrice de Confusion Visuelle
print("Affichage de la matrice...")
cm = confusion_matrix(y_test, y_pred)
fig, ax = plt.subplots(figsize=(10, 10))
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=CLASS_NAMES)
disp.plot(cmap='Blues', ax=ax, values_format='d')
plt.title(f'Matrice de Confusion\nAccuracy: {acc:.2%}')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# 5. Courbes
if best_run_history:
    plt.figure(figsize=(12, 5))
    plt.subplot(1, 2, 1)
    plt.plot(best_run_history.history['accuracy'], label='Train')
    plt.plot(best_run_history.history['val_accuracy'], label='Val')
    plt.title('Accuracy')
    plt.legend()
    plt.subplot(1, 2, 2)
    plt.plot(best_run_history.history['loss'], label='Train')
    plt.plot(best_run_history.history['val_loss'], label='Val')
    plt.title('Loss')
    plt.legend()
    plt.show()

# ==========================================
# 8. ANALYSES AVANCÉES SUPPLÉMENTAIRES
# ==========================================
print("\n" + "="*40)
print("       ANALYSES COMPLÉMENTAIRES")
print("="*40)

# --- A. TOP-K ACCURACY ---
# On regarde si la bonne réponse est dans les 3 prédictions les plus probables
k = 3
top_k_probs = tf.math.top_k(y_pred_probs, k=k).indices
y_test_tensor = tf.convert_to_tensor(y_test)
y_test_tensor = tf.expand_dims(y_test_tensor, 1) # Formatage pour comparaison

# Comparaison (Broadcasting)
matches = tf.reduce_any(tf.equal(top_k_probs, tf.cast(y_test_tensor, tf.int32)), axis=1)
top_k_acc = tf.reduce_mean(tf.cast(matches, tf.float32)).numpy()

print(f"\n>>> TOP-{k} ACCURACY : {top_k_acc:.2%} <<<")
print(f"(La bonne réponse est dans le top {k} des propositions du modèle)")


# --- B. VISUALISATION DES ERREURS (Le "Best Of" des ratés) ---
print("\nGénération de la planche des erreurs...")

# Récupérer les indices où le modèle s'est trompé
errors_indices = np.where(y_pred != y_test)[0]
nb_errors_to_show = min(10, len(errors_indices)) # On en montre 10 max

if nb_errors_to_show > 0:
    # Choix aléatoire parmi les erreurs
    random_errors = np.random.choice(errors_indices, nb_errors_to_show, replace=False)

    plt.figure(figsize=(15, 5))
    for i, idx in enumerate(random_errors):
        plt.subplot(2, 5, i + 1)
        # Affichage de l'image (X_test est normalisé, pas besoin de modif)
        plt.imshow(X_test[idx])
        
        true_label = CLASS_NAMES[y_test[idx]]
        pred_label = CLASS_NAMES[y_pred[idx]]
        prob = y_pred_probs[idx][y_pred[idx]]
        
        # Titre : Vrai -> Predit (Confiance)
        plt.title(f"Vrai: {true_label}\nPrédit: {pred_label}\n({prob:.0%})", color='red', fontsize=9)
        plt.axis('off')
    
    plt.suptitle("Analyse des Erreurs : Sur quelles images le modèle échoue-t-il ?", fontsize=14)
    plt.tight_layout()
    plt.show()
else:
    print("Incroyable ! Aucune erreur à afficher.")


# --- C. ANALYSE DE LA CONFIANCE (Histogramme) ---
# Est-ce que le modèle est "sûr de lui" quand il a raison vs quand il a tort ?

correct_indices = np.where(y_pred == y_test)[0]
prob_correct = np.max(y_pred_probs[correct_indices], axis=1)
prob_error = np.max(y_pred_probs[errors_indices], axis=1)

plt.figure(figsize=(10, 5))
plt.hist(prob_correct, bins=20, alpha=0.7, color='green', label='Prédictions Correctes')
plt.hist(prob_error, bins=20, alpha=0.7, color='red', label='Erreurs')
plt.xlabel('Confiance du modèle (Probabilité max)')
plt.ylabel('Nombre d\'images')
plt.title('Distribution de la confiance : Le modèle doute-t-il quand il se trompe ?')
plt.legend()
plt.grid(True, alpha=0.3)
plt.show()