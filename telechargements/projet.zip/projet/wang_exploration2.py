import pandas as pd
import numpy as np

# 1. Importer le tableau de mesure depuis le fichier Excel
# Assurez-vous d'avoir installé la librairie nécessaire : pip install xlrd (pour .xls) ou openpyxl (pour .xlsx)
file_path = 'WangSignatures.xls' 

# header=None indique qu'il n'y a pas de ligne d'en-tête, les données commencent ligne 0
df = pd.read_excel(file_path, header=None)


# 2. Traitement pour aligner les indices
# On extrait le numéro 'i' du nom de fichier 'i.jpg' situé dans la première colonne (colonne 0)
# Cela permet de trier les images dans l'ordre numérique (0, 1, 2...) et non alphabétique
df['image_id'] = df[0].apply(lambda x: int(x.split('.')[0]))

# On trie le DataFrame par identifiant d'image pour que l'indice du tableau corresponde au numéro de l'image
# Ainsi, la ligne i du tableau correspondra bien à l'image i.jpg
df = df.sort_values('image_id').reset_index(drop=True)

# Extraction des mesures (toutes les colonnes sauf la première contenant le nom et la dernière contenant l'ID calculé)
mesures = df.iloc[:, 1:-1].values

# 3. Créer le vecteur de label
# La base Wang contient 10 classes de 100 images.
# La classe est définie par la division entière de l'ID par 100 (ex: 0-99 -> classe 0, 100-199 -> classe 1)
label = (df['image_id'] // 100).values

# Vérification
print(f"Taille du vecteur label : {len(label)}")
print(f"Classe de l'image 150.jpg (label[150]) : {label[(150)]}") # Devrait afficher 1
print(f"Classe de l'image 450.jpg (label[450]) : {label[(450)]}")
print(f"Classe de l'image 850.jpg (label[850]) : {label[(850)]}")

print(df.head())
# Si la colonne 1 contient des chiffres entiers (0, 1, 2...), c'est la classe !